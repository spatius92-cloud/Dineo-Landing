/**
 * ============================================================
 *  IMAGES CONFIGURATION — images.js
 * ============================================================
 *  HOW TO ADD DINEO'S PHOTOS:
 *
 *  1. Drop your photo files into the /images/ folder
 *     (supports .jpg, .jpeg, .png, .webp)
 *
 *  2. Add each filename to the array below, e.g.:
 *
 *     const SLIDESHOW_IMAGES = [
 *       "images/photo1.jpg",
 *       "images/date-night.png",
 *       "images/smile.jpg"
 *     ];
 *
 *  3. Save this file and refresh the browser. Done!
 *
 *  TIP: Best results with portrait/vertical photos.
 *       Landscape photos will be cropped to fill the screen.
 * ============================================================
 */

const SLIDESHOW_IMAGES = [
  // Add your photo paths here, e.g.:
  // "images/photo1.jpg",
  // "images/photo2.jpg",
  // "images/photo3.jpg",
];

// Slideshow timing — change to adjust how long each photo shows (in ms)
const SLIDE_DURATION = 4000;   // 4 seconds per slide
const SLIDE_TRANSITION = 1200; // 1.2 second crossfade
